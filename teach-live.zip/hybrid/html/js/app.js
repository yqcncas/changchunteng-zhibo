// 初始化IM
Vue.prototype.$IM = new IM('eceabf693fae4651cba841dc', '33c08349660ddf12ff896585', 'random_str')
Vue.prototype.$IM.init()
