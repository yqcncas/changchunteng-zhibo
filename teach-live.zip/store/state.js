export default {
	chatRoomList: [], // 聊天室消息列表
}
